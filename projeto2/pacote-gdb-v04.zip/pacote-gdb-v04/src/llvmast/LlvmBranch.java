package llvmast;
public  class LlvmBranch extends LlvmInstruction{

    public LlvmBranch(LlvmLabelValue label){

    }
    
    public LlvmBranch(LlvmValue cond,  LlvmLabelValue brTrue, LlvmLabelValue brFalse){

    }

    public String toString(){
		return null;
    }
}