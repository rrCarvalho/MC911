package llvmast;
public  class LlvmIcmp extends LlvmInstruction{
    
    public LlvmIcmp(LlvmRegister lhs,  int conditionCode, LlvmType type, LlvmValue op1, LlvmValue op2){

    }

    public String toString(){
		return null;
    }
}