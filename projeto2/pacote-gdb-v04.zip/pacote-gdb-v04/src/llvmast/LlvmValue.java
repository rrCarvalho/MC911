package llvmast;
public abstract class LlvmValue{
    public LlvmType type;
}