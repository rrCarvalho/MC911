package llvmast;

public  class LlvmMinus extends LlvmInstruction{

	public LlvmMinus(LlvmRegister lhs, LlvmType type, LlvmValue op1, LlvmValue op2){

    }

    public String toString(){
		return null;
    }
}
