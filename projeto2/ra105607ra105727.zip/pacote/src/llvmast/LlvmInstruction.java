package llvmast;
public abstract class LlvmInstruction{
}