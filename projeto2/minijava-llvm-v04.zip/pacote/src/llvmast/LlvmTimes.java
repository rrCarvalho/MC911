package llvmast;
public  class LlvmTimes extends LlvmInstruction{

    public LlvmTimes(LlvmRegister lhs, LlvmType type, LlvmValue op1, LlvmValue op2){
    }

    public String toString(){
		return null;
    }
}